import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase } from './supabase';
import type { Profile } from './types';
import type { User, Session } from '@supabase/supabase-js';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  session: Session | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  session: null,
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    setProfile(data);
    return data;
  };

  const ensureProfileExists = async (u: User) => {
    const existing = await fetchProfile(u.id);

    if (!existing) {
      // Profile doesn't exist yet (trigger race condition or OAuth first login)
      // Create it from user metadata
      const meta = u.user_metadata || {};
      const displayName = meta.full_name || meta.display_name || u.email?.split('@')[0] || 'User';
      const avatarUrl = meta.avatar_url || null;

      await supabase.from('profiles').insert({
        id: u.id,
        email: u.email || '',
        display_name: displayName,
        avatar_url: avatarUrl,
      });

      // Also create arc_progress rows if they don't exist
      const arcTypes = ['comeback', 'healing', 'burnout', 'discipline', 'confidence'];
      for (const arcType of arcTypes) {
        await supabase.from('arc_progress').insert({
          user_id: u.id,
          arc_type: arcType,
        }).select();
      }

      // Re-fetch the profile
      await fetchProfile(u.id);
    } else if (!existing.avatar_url && u.user_metadata?.avatar_url) {
      // Profile exists but missing Google avatar -- update it
      const meta = u.user_metadata || {};
      await supabase
        .from('profiles')
        .update({
          avatar_url: meta.avatar_url,
          display_name: meta.full_name || existing.display_name,
          updated_at: new Date().toISOString(),
        })
        .eq('id', u.id);

      await fetchProfile(u.id);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        // Use async block inside to avoid deadlock with onAuthStateChange
        (async () => {
          await ensureProfileExists(s.user);
          setLoading(false);
        })();
      } else {
        setLoading(false);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) {
        // Use async block inside to avoid deadlock
        (async () => {
          await ensureProfileExists(s.user);
        })();
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setSession(null);
  };

  return (
    <AuthContext.Provider value={{ user, profile, session, loading, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
