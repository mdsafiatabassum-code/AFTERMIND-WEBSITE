export interface Profile {
  id: string;
  email: string;
  display_name: string;
  avatar_url: string | null;
  current_arc: string;
  streak_count: number;
  longest_streak: number;
  last_active_date: string | null;
  total_missions_completed: number;
  total_episodes: number;
  bio: string;
  created_at: string;
  updated_at: string;
}

export interface Thought {
  id: string;
  user_id: string;
  content: string;
  category: string | null;
  created_at: string;
}

export interface AIResponse {
  id: string;
  user_id: string;
  thought_id: string;
  reality_check: string;
  story_interpretation: string;
  next_mission: string;
  episode_title: string;
  arc_suggestion: string | null;
  created_at: string;
}

export interface Episode {
  id: string;
  user_id: string;
  title: string;
  episode_number: number;
  thought_id: string;
  response_id: string;
  arc: string;
  mission_completed: boolean;
  created_at: string;
}

export interface Mission {
  id: string;
  user_id: string;
  content: string;
  source_response_id: string;
  status: 'pending' | 'completed' | 'skipped';
  completed_at: string | null;
  created_at: string;
}

export interface ArcProgress {
  id: string;
  user_id: string;
  arc_type: string;
  progress: number;
  episodes_in_arc: number;
  missions_in_arc: number;
  started_at: string;
  updated_at: string;
}

export const ARC_TYPES = [
  { id: 'comeback', label: 'Comeback Arc', icon: '🔄', color: 'from-violet-500 to-blue-500' },
  { id: 'healing', label: 'Healing Arc', icon: '💚', color: 'from-emerald-500 to-teal-500' },
  { id: 'burnout', label: 'Burnout Arc', icon: '🔥', color: 'from-orange-500 to-red-500' },
  { id: 'discipline', label: 'Discipline Arc', icon: '⚡', color: 'from-amber-500 to-yellow-500' },
  { id: 'confidence', label: 'Confidence Arc', icon: '👑', color: 'from-blue-500 to-cyan-500' },
] as const;

export const CATEGORIES = [
  { id: 'overthinking', label: 'Overthinking', icon: '🌀' },
  { id: 'discipline', label: 'Discipline', icon: '⚡' },
  { id: 'burnout', label: 'Burnout', icon: '🔥' },
  { id: 'confidence', label: 'Confidence', icon: '👑' },
  { id: 'healing', label: 'Healing', icon: '💚' },
  { id: 'motivation', label: 'Motivation', icon: '🚀' },
] as const;
