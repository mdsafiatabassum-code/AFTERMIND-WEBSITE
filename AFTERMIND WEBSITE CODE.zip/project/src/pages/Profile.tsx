import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import { Loader2, Save, User, Mail, Calendar, CheckCircle2, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const { user, profile, refreshProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.display_name);
      setBio(profile.bio || '');
      setLoading(false);
    }
  }, [profile]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setSaving(true);
    setSaved(false);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          display_name: displayName.trim(),
          bio: bio.trim(),
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch {
      // Error silently handled
    } finally {
      setSaving(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/signin', { replace: true });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-violet-400 animate-spin" />
      </div>
    );
  }

  const streak = profile?.streak_count || 0;
  const totalEpisodes = profile?.total_episodes || 0;
  const totalMissions = profile?.total_missions_completed || 0;
  const avatarUrl = profile?.avatar_url;
  const initials = profile?.display_name?.[0]?.toUpperCase() || '?';

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Profile</h1>
        <p className="text-slate-400 text-sm mt-1">Your identity in the story.</p>
      </div>

      {/* Avatar and name header */}
      <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 flex items-center gap-5">
        {avatarUrl ? (
          <img
            src={avatarUrl}
            alt={profile?.display_name}
            className="w-16 h-16 rounded-full object-cover border-2 border-violet-500/20"
          />
        ) : (
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500/30 to-blue-500/30 flex items-center justify-center text-violet-300 text-2xl font-bold border-2 border-violet-500/20">
            {initials}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <h2 className="text-lg font-semibold text-white truncate">{profile?.display_name}</h2>
          <p className="text-sm text-slate-500 truncate">{profile?.email}</p>
          {profile?.current_arc && (
            <span className="inline-block mt-1.5 text-[10px] font-medium text-violet-400 bg-violet-500/10 border border-violet-500/20 rounded-full px-2.5 py-0.5 capitalize">
              {profile.current_arc} arc
            </span>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4 text-center">
          <p className="text-xl font-bold text-white">{streak}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Day Streak</p>
        </div>
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4 text-center">
          <p className="text-xl font-bold text-white">{totalEpisodes}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Episodes</p>
        </div>
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4 text-center">
          <p className="text-xl font-bold text-white">{totalMissions}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Missions</p>
        </div>
      </div>

      {/* Edit form */}
      <form onSubmit={handleSave} className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-6 space-y-5">
        <div>
          <label htmlFor="displayName" className="block text-sm font-medium text-slate-300 mb-1.5">
            Display name
          </label>
          <div className="relative">
            <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              id="displayName"
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
              className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl pl-11 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500/40 focus:border-violet-500/40 transition"
              placeholder="Your name"
            />
          </div>
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-1.5">
            Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
            <input
              id="email"
              type="email"
              value={profile?.email || ''}
              disabled
              className="w-full bg-white/[0.02] border border-white/[0.04] rounded-xl pl-11 pr-4 py-3 text-slate-500 cursor-not-allowed"
            />
          </div>
        </div>

        <div>
          <label htmlFor="bio" className="block text-sm font-medium text-slate-300 mb-1.5">
            Bio
          </label>
          <textarea
            id="bio"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            rows={3}
            className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500/40 focus:border-violet-500/40 transition resize-none"
            placeholder="A few words about your journey..."
          />
        </div>

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-50 text-white font-semibold rounded-xl px-5 py-2.5 flex items-center gap-2 transition-all text-sm"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Saving...' : 'Save changes'}
          </button>
          {saved && (
            <span className="flex items-center gap-1.5 text-sm text-emerald-400 animate-fade-in">
              <CheckCircle2 className="w-4 h-4" />
              Saved
            </span>
          )}
        </div>
      </form>

      {/* Sign out */}
      <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-5">
        <button
          onClick={handleSignOut}
          className="flex items-center gap-3 text-sm font-medium text-slate-400 hover:text-red-400 transition"
        >
          <LogOut className="w-4 h-4" />
          Sign out
        </button>
      </div>

      {/* Member since */}
      <div className="flex items-center gap-2 text-xs text-slate-600">
        <Calendar className="w-3.5 h-3.5" />
        Member since {profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'recently'}
      </div>
    </div>
  );
}
