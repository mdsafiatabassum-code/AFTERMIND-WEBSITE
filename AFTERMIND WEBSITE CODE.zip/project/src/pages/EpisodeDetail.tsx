import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import type { Episode, Thought, AIResponse, Mission } from '../lib/types';
import { ARC_TYPES } from '../lib/types';
import { Eye, BookOpen, Target, ChevronLeft, Loader2, CheckCircle2, SkipForward, Flame } from 'lucide-react';

export default function EpisodeDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [episode, setEpisode] = useState<Episode | null>(null);
  const [thought, setThought] = useState<Thought | null>(null);
  const [response, setResponse] = useState<AIResponse | null>(null);
  const [mission, setMission] = useState<Mission | null>(null);
  const [loading, setLoading] = useState(true);
  const [missionLoading, setMissionLoading] = useState(false);
  const [missionSuccess, setMissionSuccess] = useState(false);

  useEffect(() => {
    if (!user || !id) return;

    const fetchData = async () => {
      // Fetch episode
      const { data: ep } = await supabase
        .from('episodes')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .maybeSingle();

      if (!ep) {
        setLoading(false);
        return;
      }

      setEpisode(ep);

      // Fetch thought
      const { data: th } = await supabase
        .from('thoughts')
        .select('*')
        .eq('id', ep.thought_id)
        .maybeSingle();
      setThought(th);

      // Fetch AI response
      const { data: ai } = await supabase
        .from('ai_responses')
        .select('*')
        .eq('id', ep.response_id)
        .maybeSingle();
      setResponse(ai);

      // Fetch mission linked to this response
      if (ai) {
        const { data: m } = await supabase
          .from('missions')
          .select('*')
          .eq('source_response_id', ai.id)
          .eq('user_id', user.id)
          .maybeSingle();
        setMission(m);
      }

      setLoading(false);
    };

    fetchData();
  }, [user, id]);

  const handleMissionComplete = async () => {
    if (!mission || !user) return;
    setMissionLoading(true);

    try {
      await supabase
        .from('missions')
        .update({ status: 'completed', completed_at: new Date().toISOString() })
        .eq('id', mission.id);

      await supabase
        .from('episodes')
        .update({ mission_completed: true })
        .eq('id', episode!.id);

      setMission({ ...mission, status: 'completed', completed_at: new Date().toISOString() });
      setEpisode({ ...episode!, mission_completed: true });
      setMissionSuccess(true);
      setTimeout(() => setMissionSuccess(false), 3000);
    } catch {
      // Silently handle
    } finally {
      setMissionLoading(false);
    }
  };

  const handleMissionSkip = async () => {
    if (!mission || !user) return;
    setMissionLoading(true);

    try {
      await supabase
        .from('missions')
        .update({ status: 'skipped' })
        .eq('id', mission.id);

      setMission({ ...mission, status: 'skipped' });
    } catch {
      // Silently handle
    } finally {
      setMissionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-violet-400 animate-spin" />
      </div>
    );
  }

  if (!episode) {
    return (
      <div className="text-center py-20">
        <p className="text-slate-400 mb-4">Episode not found.</p>
        <button onClick={() => navigate('/home')} className="text-violet-400 hover:text-violet-300 text-sm">
          Go home
        </button>
      </div>
    );
  }

  const arcInfo = ARC_TYPES.find((a) => a.id === episode.arc);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Back button */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-white transition"
      >
        <ChevronLeft className="w-4 h-4" />
        Back
      </button>

      {/* Episode header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600/10 via-blue-600/5 to-transparent border border-violet-500/10 p-6 sm:p-8">
        <div className="absolute top-0 right-0 w-48 h-48 bg-violet-500/5 rounded-full blur-[60px] pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3">
            {arcInfo && (
              <span className={`text-xs font-medium px-2.5 py-1 rounded-full bg-gradient-to-r ${arcInfo.color} bg-opacity-20 border border-white/[0.06]`}>
                {arcInfo.icon} {arcInfo.label}
              </span>
            )}
            <span className="text-xs text-slate-500">
              {new Date(episode.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white">{episode.title}</h1>
          {thought && (
            <p className="text-slate-400 text-sm mt-3 italic max-w-lg">"{thought.content}"</p>
          )}
        </div>
      </div>

      {/* Mission success */}
      {missionSuccess && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-sm text-emerald-300">Mission completed! Your progress has been updated.</p>
        </div>
      )}

      {/* AI Response cards */}
      {response && (
        <div className="space-y-4">
          <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-5 sm:p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <Eye className="w-4 h-4 text-rose-400" />
              <h3 className="text-sm font-semibold text-white">Reality Check</h3>
            </div>
            <p className="text-slate-200 leading-relaxed">{response.reality_check}</p>
          </div>

          <div className="bg-violet-500/10 border border-violet-500/20 rounded-2xl p-5 sm:p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <BookOpen className="w-4 h-4 text-violet-400" />
              <h3 className="text-sm font-semibold text-white">Story Interpretation</h3>
            </div>
            <p className="text-slate-200 leading-relaxed">{response.story_interpretation}</p>
          </div>

          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-5 sm:p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <Target className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-white">Next Mission</h3>
            </div>
            <p className="text-slate-200 leading-relaxed">{response.next_mission}</p>
          </div>
        </div>
      )}

      {/* Mission actions */}
      {mission && mission.status === 'pending' && (
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Flame className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Mission Status</h3>
          </div>
          <p className="text-slate-300 text-sm mb-4">{mission.content}</p>
          <div className="flex gap-2">
            <button
              onClick={handleMissionComplete}
              disabled={missionLoading}
              className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-50 text-white text-sm font-medium rounded-xl px-4 py-2 transition-all flex items-center gap-2"
            >
              {missionLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
              Mark Complete
            </button>
            <button
              onClick={handleMissionSkip}
              disabled={missionLoading}
              className="bg-white/[0.04] border border-white/[0.08] text-slate-400 text-sm font-medium rounded-xl px-4 py-2 hover:text-white disabled:opacity-50 transition flex items-center gap-2"
            >
              <SkipForward className="w-3.5 h-3.5" />
              Skip
            </button>
          </div>
        </div>
      )}

      {mission && mission.status === 'completed' && (
        <div className="bg-emerald-500/5 border border-emerald-500/15 rounded-2xl p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <p className="text-sm font-medium text-emerald-300">Mission completed</p>
            {mission.completed_at && (
              <p className="text-xs text-slate-500">{new Date(mission.completed_at).toLocaleDateString()}</p>
            )}
          </div>
        </div>
      )}

      {mission && mission.status === 'skipped' && (
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 flex items-center gap-3">
          <SkipForward className="w-5 h-5 text-slate-500 shrink-0" />
          <p className="text-sm text-slate-400">Mission skipped</p>
        </div>
      )}
    </div>
  );
}
