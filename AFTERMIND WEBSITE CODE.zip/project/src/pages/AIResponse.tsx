import { useLocation, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import type { AIResponse } from '../lib/types';
import { Eye, BookOpen, Target, ChevronRight, Sparkles, Loader2 } from 'lucide-react';

export default function AIResponseView() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [aiResponse, setAiResponse] = useState<AIResponse | null>(null);
  const [thought, setThought] = useState('');
  const [showCards, setShowCards] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // First try to get data from navigation state
    const stateData = (location.state as { aiResponse?: AIResponse; thought?: string }) || {};
    if (stateData.aiResponse) {
      setAiResponse(stateData.aiResponse);
      setThought(stateData.thought || '');
      setLoading(false);
      return;
    }

    // If no state (e.g., page refresh), fetch the latest AI response from DB
    if (!user) {
      navigate('/signin', { replace: true });
      return;
    }

    const fetchLatestResponse = async () => {
      const { data } = await supabase
        .from('ai_responses')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (data) {
        setAiResponse(data);

        // Also fetch the associated thought
        const { data: thoughtData } = await supabase
          .from('thoughts')
          .select('content')
          .eq('id', data.thought_id)
          .maybeSingle();

        if (thoughtData) {
          setThought(thoughtData.content);
        }
      }

      setLoading(false);
    };

    fetchLatestResponse();
  }, [location.state, user, navigate]);

  // Trigger card animations
  useEffect(() => {
    if (aiResponse && !showCards) {
      const timer = setTimeout(() => setShowCards(true), 100);
      return () => clearTimeout(timer);
    }
  }, [aiResponse, showCards]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-violet-400 animate-spin" />
      </div>
    );
  }

  if (!aiResponse) {
    return (
      <div className="text-center py-20">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/[0.06] mb-4">
          <Sparkles className="w-7 h-7 text-slate-600" />
        </div>
        <h2 className="text-lg font-semibold text-white mb-2">No response yet</h2>
        <p className="text-slate-400 text-sm mb-4">Share a thought to get your reality check.</p>
        <button
          onClick={() => navigate('/share')}
          className="text-violet-400 hover:text-violet-300 text-sm font-medium"
        >
          Share a thought
        </button>
      </div>
    );
  }

  const cards = [
    {
      icon: Eye,
      label: 'Reality Check',
      content: aiResponse.reality_check,
      gradient: 'from-rose-500/20 to-orange-500/20',
      border: 'border-rose-500/20',
      iconColor: 'text-rose-400',
      delay: '0ms',
    },
    {
      icon: BookOpen,
      label: 'Story Interpretation',
      content: aiResponse.story_interpretation,
      gradient: 'from-violet-500/20 to-blue-500/20',
      border: 'border-violet-500/20',
      iconColor: 'text-violet-400',
      delay: '200ms',
    },
    {
      icon: Target,
      label: 'Next Mission',
      content: aiResponse.next_mission,
      gradient: 'from-emerald-500/20 to-teal-500/20',
      border: 'border-emerald-500/20',
      iconColor: 'text-emerald-400',
      delay: '400ms',
    },
  ];

  return (
    <div className="max-w-2xl mx-auto">
      {/* Episode title */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-gradient-to-r from-violet-600/20 to-blue-600/20 border border-violet-500/20 rounded-full px-4 py-1.5 mb-4">
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span className="text-xs font-medium text-violet-300">New Episode</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white">{aiResponse.episode_title}</h1>
        {thought && (
          <p className="text-slate-400 text-sm mt-3 max-w-md mx-auto italic">"{thought}"</p>
        )}
      </div>

      {/* Response cards */}
      <div className="space-y-4">
        {cards.map((card) => (
          <div
            key={card.label}
            className={`transition-all duration-700 ease-out ${
              showCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ transitionDelay: card.delay }}
          >
            <div className={`bg-gradient-to-br ${card.gradient} border ${card.border} rounded-2xl p-5 sm:p-6`}>
              <div className="flex items-center gap-2.5 mb-3">
                <card.icon className={`w-4 h-4 ${card.iconColor}`} />
                <h3 className="text-sm font-semibold text-white">{card.label}</h3>
              </div>
              <p className="text-slate-200 leading-relaxed">{card.content}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Arc suggestion */}
      {aiResponse.arc_suggestion && (
        <div
          className={`mt-4 text-center transition-all duration-700 ${
            showCards ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ transitionDelay: '600ms' }}
        >
          <p className="text-xs text-slate-500">
            Current arc: <span className="text-violet-400 capitalize">{aiResponse.arc_suggestion}</span>
          </p>
        </div>
      )}

      {/* Actions */}
      <div
        className={`mt-8 flex flex-col sm:flex-row gap-3 transition-all duration-700 ${
          showCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
        style={{ transitionDelay: '600ms' }}
      >
        <button
          onClick={() => navigate('/home')}
          className="flex-1 bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white font-semibold rounded-2xl py-3.5 flex items-center justify-center gap-2 transition-all shadow-lg shadow-violet-500/20"
        >
          Continue Journey
          <ChevronRight className="w-4 h-4" />
        </button>
        <button
          onClick={() => navigate('/share')}
          className="flex-1 bg-white/[0.04] border border-white/[0.08] text-slate-300 font-medium rounded-2xl py-3.5 hover:bg-white/[0.06] transition flex items-center justify-center gap-2"
        >
          Share Another Thought
        </button>
      </div>
    </div>
  );
}
