import { useEffect, useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import type { ArcProgress } from '../lib/types';
import { ARC_TYPES } from '../lib/types';
import { Flame, Target, BookOpen, TrendingUp, Loader2, CheckCircle2 } from 'lucide-react';

export default function Progress() {
  const { user, profile, refreshProfile } = useAuth();
  const [arcs, setArcs] = useState<ArcProgress[]>([]);
  const [loading, setLoading] = useState(true);
  const [switchingArc, setSwitchingArc] = useState<string | null>(null);
  const [arcSwitched, setArcSwitched] = useState(false);

  const fetchArcs = useCallback(async () => {
    if (!user) return;

    const { data } = await supabase
      .from('arc_progress')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false });

    setArcs(data || []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchArcs();
  }, [fetchArcs]);

  const currentArc = profile?.current_arc || 'comeback';
  const streak = profile?.streak_count || 0;
  const longestStreak = profile?.longest_streak || 0;
  const totalEpisodes = profile?.total_episodes || 0;
  const totalMissions = profile?.total_missions_completed || 0;

  const handleSwitchArc = async (arcType: string) => {
    if (!user || arcType === currentArc) return;
    setSwitchingArc(arcType);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ current_arc: arcType, updated_at: new Date().toISOString() })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
      setArcSwitched(true);
      setTimeout(() => setArcSwitched(false), 2500);
    } catch {
      // Silently handle
    } finally {
      setSwitchingArc(null);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white">Progress</h1>
        <p className="text-slate-400 text-sm mt-1">Your emotional growth journey.</p>
      </div>

      {/* Arc switch success */}
      {arcSwitched && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-sm text-emerald-300">Arc switched! Your journey continues.</p>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4">
          <Flame className={`w-5 h-5 mb-2 ${streak > 0 ? 'text-orange-400' : 'text-slate-500'}`} />
          <p className="text-2xl font-bold text-white">{streak}</p>
          <p className="text-xs text-slate-500">Current Streak</p>
        </div>
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4">
          <TrendingUp className="w-5 h-5 text-blue-400 mb-2" />
          <p className="text-2xl font-bold text-white">{longestStreak}</p>
          <p className="text-xs text-slate-500">Longest Streak</p>
        </div>
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4">
          <BookOpen className="w-5 h-5 text-violet-400 mb-2" />
          <p className="text-2xl font-bold text-white">{totalEpisodes}</p>
          <p className="text-xs text-slate-500">Episodes</p>
        </div>
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4">
          <Target className="w-5 h-5 text-emerald-400 mb-2" />
          <p className="text-2xl font-bold text-white">{totalMissions}</p>
          <p className="text-xs text-slate-500">Missions Done</p>
        </div>
      </div>

      {/* Arc progress */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Story Arcs</h2>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 text-violet-400 animate-spin" />
          </div>
        ) : (
          <div className="space-y-3">
            {ARC_TYPES.map((arcType) => {
              const arcData = arcs.find((a) => a.arc_type === arcType.id);
              const progress = arcData?.progress || 0;
              const isActive = currentArc === arcType.id;
              const isSwitching = switchingArc === arcType.id;

              return (
                <div
                  key={arcType.id}
                  className={`bg-white/[0.02] border rounded-2xl p-5 transition-all ${
                    isActive ? 'border-violet-500/30 bg-violet-500/[0.03]' : 'border-white/[0.06]'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${arcType.color} flex items-center justify-center`}>
                      <span className="text-base">{arcType.icon}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-white text-sm">{arcType.label}</h3>
                        {isActive && (
                          <span className="text-[10px] font-medium text-violet-400 bg-violet-500/10 border border-violet-500/20 rounded-full px-2 py-0.5">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">
                        {arcData?.episodes_in_arc || 0} episodes &middot; {arcData?.missions_in_arc || 0} missions
                      </p>
                    </div>
                    <span className="text-sm font-semibold text-white">{progress}%</span>
                  </div>

                  {/* Progress bar */}
                  <div className="h-1.5 bg-white/[0.04] rounded-full overflow-hidden mb-3">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${arcType.color} transition-all duration-1000 ease-out`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>

                  {/* Switch arc button */}
                  {!isActive && (
                    <button
                      onClick={() => handleSwitchArc(arcType.id)}
                      disabled={switchingArc !== null}
                      className="text-xs font-medium text-slate-400 hover:text-violet-300 disabled:opacity-50 transition flex items-center gap-1.5"
                    >
                      {isSwitching ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : null}
                      Switch to this arc
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
