import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import type { Episode, Thought, AIResponse } from '../lib/types';
import { ARC_TYPES, CATEGORIES } from '../lib/types';
import { Loader2, BookOpen, Filter, Eye, Target, ChevronDown, ChevronUp } from 'lucide-react';

interface HistoryEntry {
  episode: Episode;
  thought: Thought;
  response: AIResponse | null;
}

export default function History() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterArc, setFilterArc] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('');
  const [showFilters, setShowFilters] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchHistory = useCallback(async () => {
    if (!user) return;

    const { data: episodes } = await supabase
      .from('episodes')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!episodes || episodes.length === 0) {
      setLoading(false);
      return;
    }

    // Fetch associated thoughts
    const thoughtIds = episodes.map((ep) => ep.thought_id);
    const { data: thoughts } = await supabase
      .from('thoughts')
      .select('*')
      .in('id', thoughtIds);

    const thoughtMap = new Map(thoughts?.map((t) => [t.id, t]));

    // Fetch associated AI responses
    const responseIds = episodes.map((ep) => ep.response_id);
    const { data: responses } = await supabase
      .from('ai_responses')
      .select('*')
      .in('id', responseIds);

    const responseMap = new Map(responses?.map((r) => [r.id, r]));

    const historyEntries = episodes.map((ep) => ({
      episode: ep,
      thought: thoughtMap.get(ep.thought_id) as Thought,
      response: responseMap.get(ep.response_id) as AIResponse | null,
    }));

    setEntries(historyEntries);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const filteredEntries = entries.filter((entry) => {
    if (filterArc && entry.episode.arc !== filterArc) return false;
    if (filterCategory && entry.thought?.category !== filterCategory) return false;
    return true;
  });

  const getArcLabel = (arcId: string) => ARC_TYPES.find((a) => a.id === arcId)?.label || arcId;
  const getCategoryLabel = (catId: string) => CATEGORIES.find((c) => c.id === catId)?.label || catId;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">History</h1>
          <p className="text-slate-400 text-sm mt-1">Your past episodes and thoughts.</p>
        </div>
        {entries.length > 0 && (
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-xl border transition ${
              showFilters || filterArc || filterCategory
                ? 'bg-violet-500/10 text-violet-300 border-violet-500/20'
                : 'bg-white/[0.03] text-slate-400 border-white/[0.06] hover:text-slate-200'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            Filter
            {showFilters ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        )}
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 space-y-4 animate-fade-in">
          <div>
            <p className="text-xs text-slate-500 mb-2">Arc</p>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setFilterArc('')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  !filterArc
                    ? 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                    : 'bg-white/[0.03] text-slate-400 border border-white/[0.06]'
                }`}
              >
                All
              </button>
              {ARC_TYPES.map((arc) => (
                <button
                  key={arc.id}
                  onClick={() => setFilterArc(filterArc === arc.id ? '' : arc.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    filterArc === arc.id
                      ? 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                      : 'bg-white/[0.03] text-slate-400 border border-white/[0.06]'
                  }`}
                >
                  {arc.icon} {arc.label.replace(' Arc', '')}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-2">Category</p>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setFilterCategory('')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  !filterCategory
                    ? 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                    : 'bg-white/[0.03] text-slate-400 border border-white/[0.06]'
                }`}
              >
                All
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setFilterCategory(filterCategory === cat.id ? '' : cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    filterCategory === cat.id
                      ? 'bg-violet-500/10 text-violet-300 border border-violet-500/20'
                      : 'bg-white/[0.03] text-slate-400 border border-white/[0.06]'
                  }`}
                >
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-5 h-5 text-violet-400 animate-spin" />
        </div>
      ) : filteredEntries.length === 0 ? (
        <div className="text-center py-16">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/[0.06] mb-4">
            <BookOpen className="w-7 h-7 text-slate-600" />
          </div>
          <h2 className="text-lg font-semibold text-white mb-2">
            {entries.length === 0 ? 'No episodes yet' : 'No matching episodes'}
          </h2>
          <p className="text-slate-400 text-sm max-w-xs mx-auto">
            {entries.length === 0
              ? 'Share your first thought to begin your story.'
              : 'Try adjusting your filters.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEntries.map(({ episode, thought, response }) => {
            const isExpanded = expandedId === episode.id;

            return (
              <div
                key={episode.id}
                className="bg-white/[0.02] border border-white/[0.06] rounded-2xl overflow-hidden hover:bg-white/[0.04] transition"
              >
                <button
                  onClick={() => setExpandedId(isExpanded ? null : episode.id)}
                  className="w-full text-left p-5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-white text-sm">{episode.title}</h3>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="text-xs text-slate-500 capitalize">{getArcLabel(episode.arc)}</span>
                        {thought?.category && (
                          <span className="text-xs text-slate-600">&middot; {getCategoryLabel(thought.category)}</span>
                        )}
                        {episode.mission_completed && (
                          <span className="text-[10px] font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-2 py-0.5">
                            Mission Complete
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-600 shrink-0">
                      {new Date(episode.created_at).toLocaleDateString()}
                      <ChevronDown className={`w-3.5 h-3.5 transition ${isExpanded ? 'rotate-180' : ''}`} />
                    </div>
                  </div>
                  {thought && (
                    <p className="text-sm text-slate-400 italic line-clamp-2 mt-2">"{thought.content}"</p>
                  )}
                </button>

                {/* Expanded view with AI response */}
                {isExpanded && response && (
                  <div className="px-5 pb-5 space-y-3 border-t border-white/[0.04] pt-4 animate-fade-in">
                    <div className="bg-rose-500/10 border border-rose-500/15 rounded-xl p-3">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Eye className="w-3.5 h-3.5 text-rose-400" />
                        <span className="text-xs font-semibold text-rose-300">Reality Check</span>
                      </div>
                      <p className="text-sm text-slate-300">{response.reality_check}</p>
                    </div>
                    <div className="bg-violet-500/10 border border-violet-500/15 rounded-xl p-3">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <BookOpen className="w-3.5 h-3.5 text-violet-400" />
                        <span className="text-xs font-semibold text-violet-300">Story Interpretation</span>
                      </div>
                      <p className="text-sm text-slate-300">{response.story_interpretation}</p>
                    </div>
                    <div className="bg-emerald-500/10 border border-emerald-500/15 rounded-xl p-3">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Target className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-xs font-semibold text-emerald-300">Next Mission</span>
                      </div>
                      <p className="text-sm text-slate-300">{response.next_mission}</p>
                    </div>
                    <Link
                      to={`/episode/${episode.id}`}
                      className="flex items-center gap-1.5 text-xs font-medium text-violet-400 hover:text-violet-300 transition mt-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      View full episode
                    </Link>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
