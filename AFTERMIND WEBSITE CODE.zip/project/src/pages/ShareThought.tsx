import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import { CATEGORIES } from '../lib/types';
import { Loader2, Sparkles } from 'lucide-react';

export default function ShareThought() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const preselectedCategory = (location.state as { preselectedCategory?: string })?.preselectedCategory || '';
  const [content, setContent] = useState('');
  const [category, setCategory] = useState(preselectedCategory);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const placeholders = [
    "What's weighing on your mind today?",
    "What are you struggling with right now?",
    "Tell AfterMind what's been on your chest...",
    "What's the thought you can't shake?",
    "What would you tell a friend if you were honest?",
  ];

  const placeholder = placeholders[Math.floor(Math.random() * placeholders.length)];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !user) return;

    setError('');
    setSubmitting(true);

    try {
      // Save the thought
      const { data: thought, error: thoughtError } = await supabase
        .from('thoughts')
        .insert({
          user_id: user.id,
          content: content.trim(),
          category: category || null,
        })
        .select()
        .single();

      if (thoughtError) throw thoughtError;

      // Call AI
      const episodeNumber = (profile?.total_episodes || 0) + 1;
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/aftermind-ai`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          thought: content.trim(),
          category: category || 'overthinking',
          episodeNumber,
          currentArc: profile?.current_arc || 'comeback',
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'AI processing failed');
      }

      const aiData = await response.json();

      // Validate AI response has required fields
      if (!aiData.reality_check || !aiData.story_interpretation || !aiData.next_mission) {
        throw new Error('AI response was incomplete. Please try again.');
      }

      // Ensure episode title includes the number
      let episodeTitle = aiData.episode_title || `Episode ${episodeNumber}: A New Chapter`;
      if (!episodeTitle.includes(String(episodeNumber))) {
        episodeTitle = `Episode ${episodeNumber}: ${episodeTitle}`;
      }

      const arcSuggestion = aiData.arc_suggestion || profile?.current_arc || 'comeback';

      // Save AI response
      const { data: aiResponse, error: responseError } = await supabase
        .from('ai_responses')
        .insert({
          user_id: user.id,
          thought_id: thought.id,
          reality_check: aiData.reality_check,
          story_interpretation: aiData.story_interpretation,
          next_mission: aiData.next_mission,
          episode_title: episodeTitle,
          arc_suggestion: arcSuggestion,
        })
        .select()
        .single();

      if (responseError) throw responseError;

      // Save episode
      const { error: episodeError } = await supabase.from('episodes').insert({
        user_id: user.id,
        title: episodeTitle,
        episode_number: episodeNumber,
        thought_id: thought.id,
        response_id: aiResponse.id,
        arc: arcSuggestion,
        mission_completed: false,
      });

      if (episodeError) throw episodeError;

      // Save mission
      const { error: missionError } = await supabase.from('missions').insert({
        user_id: user.id,
        content: aiData.next_mission,
        source_response_id: aiResponse.id,
        status: 'pending',
      });

      if (missionError) throw missionError;

      // Update profile streak and episode count
      const today = new Date().toISOString().split('T')[0];
      const lastActive = profile?.last_active_date;
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

      let newStreak = profile?.streak_count || 0;
      if (lastActive === yesterday) {
        newStreak += 1;
      } else if (lastActive !== today) {
        newStreak = 1;
      }

      const newLongest = Math.max(newStreak, profile?.longest_streak || 0);

      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          streak_count: newStreak,
          longest_streak: newLongest,
          last_active_date: today,
          total_episodes: episodeNumber,
          current_arc: arcSuggestion,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // Update arc progress - create if not exists, update if exists
      const { data: existingArc } = await supabase
        .from('arc_progress')
        .select('*')
        .eq('user_id', user.id)
        .eq('arc_type', arcSuggestion)
        .maybeSingle();

      if (existingArc) {
        const newProgress = Math.min(100, existingArc.progress + 5);
        await supabase
          .from('arc_progress')
          .update({
            progress: newProgress,
            episodes_in_arc: existingArc.episodes_in_arc + 1,
            updated_at: new Date().toISOString(),
          })
          .eq('id', existingArc.id);
      } else {
        // Create new arc progress row if it doesn't exist
        await supabase.from('arc_progress').insert({
          user_id: user.id,
          arc_type: arcSuggestion,
          progress: 5,
          episodes_in_arc: 1,
          missions_in_arc: 0,
        });
      }

      // Refresh profile so UI shows updated streak/episode data
      await refreshProfile();

      // Navigate to response view
      navigate('/response', { state: { aiResponse, thought: content.trim() } });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Share Your Thoughts</h1>
        <p className="text-slate-400 text-sm mt-1">Let AfterMind understand what you're going through.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Category selection */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">What area does this relate to?</label>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(category === cat.id ? '' : cat.id)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  category === cat.id
                    ? 'bg-gradient-to-r from-violet-600/30 to-blue-600/30 text-violet-300 border border-violet-500/30'
                    : 'bg-white/[0.03] text-slate-400 border border-white/[0.06] hover:border-white/[0.12] hover:text-slate-200'
                }`}
              >
                <span className="mr-1.5">{cat.icon}</span>
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Thought input */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">What's on your mind?</label>
          <div className="relative">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
              rows={6}
              className="w-full bg-white/[0.03] border border-white/[0.06] rounded-2xl px-5 py-4 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500/30 focus:border-violet-500/30 transition resize-none text-base leading-relaxed"
              placeholder={placeholder}
            />
            <div className="absolute bottom-3 right-3 text-xs text-slate-600">
              {content.length > 0 && `${content.length} chars`}
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-400">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting || !content.trim()}
          className="w-full bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-2xl py-4 flex items-center justify-center gap-2.5 transition-all shadow-lg shadow-violet-500/20 text-base"
        >
          {submitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              AfterMind is thinking...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Get Your Reality Check
            </>
          )}
        </button>
      </form>
    </div>
  );
}
