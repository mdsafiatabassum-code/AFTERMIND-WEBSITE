import { Link } from 'react-router-dom';
import { CATEGORIES, ARC_TYPES } from '../lib/types';
import { ChevronRight, PenLine } from 'lucide-react';

const reflections = [
  "You don't have to have it all figured out. You just have to take the next step.",
  "The version of you that survives this will be someone you haven't met yet.",
  "Rest is not the opposite of progress. Sometimes it's the most productive thing you can do.",
  "You're not behind. You're on your own timeline.",
  "The fact that you're still trying means you haven't given up on yourself.",
  "Growth is uncomfortable. Comfort is a sign you're staying the same.",
];

export default function Explore() {
  const dailyReflection = reflections[new Date().getDate() % reflections.length];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white">Explore</h1>
        <p className="text-slate-400 text-sm mt-1">Discover your emotional landscape.</p>
      </div>

      {/* Daily reflection */}
      <div className="bg-gradient-to-br from-violet-600/10 to-blue-600/5 border border-violet-500/10 rounded-2xl p-6">
        <p className="text-xs text-violet-400 font-medium mb-2">Daily Reflection</p>
        <p className="text-slate-200 italic leading-relaxed">"{dailyReflection}"</p>
      </div>

      {/* Quick share */}
      <Link
        to="/share"
        className="flex items-center gap-4 bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5 hover:bg-white/[0.05] transition-all group"
      >
        <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-500/20 to-blue-500/20 flex items-center justify-center shrink-0">
          <PenLine className="w-5 h-5 text-violet-300" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-white text-sm">Share What's on Your Mind</h3>
          <p className="text-xs text-slate-400">Get your reality check and next mission</p>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-violet-400 transition shrink-0" />
      </Link>

      {/* Emotional categories */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Categories</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              to={`/share`}
              state={{ preselectedCategory: cat.id }}
              className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-4 hover:bg-white/[0.05] hover:border-white/[0.1] transition-all text-center group"
            >
              <span className="text-2xl block mb-2">{cat.icon}</span>
              <span className="text-sm font-medium text-slate-300 group-hover:text-white transition">{cat.label}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Story arcs */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Story Arcs</h2>
        <div className="space-y-3">
          {ARC_TYPES.map((arc) => (
            <Link
              key={arc.id}
              to="/progress"
              className="flex items-center gap-4 bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4 hover:bg-white/[0.04] transition-all group"
            >
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${arc.color} flex items-center justify-center shrink-0`}>
                <span className="text-lg">{arc.icon}</span>
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-white text-sm">{arc.label}</h3>
                <p className="text-xs text-slate-500">Track your {arc.label.toLowerCase()} progression</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-violet-400 transition shrink-0" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
