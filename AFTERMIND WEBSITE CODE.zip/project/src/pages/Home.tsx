import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import type { Episode, Mission } from '../lib/types';
import { Flame, PenLine, ChevronRight, Sparkles, Loader2, CheckCircle2, Eye } from 'lucide-react';

export default function Home() {
  const { user, profile, refreshProfile } = useAuth();
  const [latestEpisode, setLatestEpisode] = useState<Episode | null>(null);
  const [pendingMission, setPendingMission] = useState<Mission | null>(null);
  const [loading, setLoading] = useState(true);
  const [missionLoading, setMissionLoading] = useState<'complete' | 'skip' | null>(null);
  const [missionSuccess, setMissionSuccess] = useState(false);

  const fetchData = useCallback(async () => {
    if (!user) return;

    const { data: episodes } = await supabase
      .from('episodes')
      .select('*')
      .eq('user_id', user.id)
      .order('episode_number', { ascending: false })
      .limit(1);

    if (episodes && episodes.length > 0) {
      setLatestEpisode(episodes[0]);
    }

    const { data: missions } = await supabase
      .from('missions')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1);

    if (missions && missions.length > 0) {
      setPendingMission(missions[0]);
    }

    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const nextEpisode = (profile?.total_episodes || 0) + 1;
  const displayName = profile?.display_name || 'there';
  const streak = profile?.streak_count || 0;

  const handleMissionComplete = async () => {
    if (!pendingMission || !user) return;
    setMissionLoading('complete');

    try {
      // Update mission status
      const { error: missionError } = await supabase
        .from('missions')
        .update({ status: 'completed', completed_at: new Date().toISOString() })
        .eq('id', pendingMission.id);

      if (missionError) throw missionError;

      // Find the episode linked to this mission's AI response and mark mission_completed
      const { data: responseEpisodes } = await supabase
        .from('episodes')
        .select('id')
        .eq('user_id', user.id)
        .eq('response_id', pendingMission.source_response_id)
        .limit(1);

      if (responseEpisodes && responseEpisodes.length > 0) {
        await supabase
          .from('episodes')
          .update({ mission_completed: true })
          .eq('id', responseEpisodes[0].id);
      }

      // Update profile total_missions_completed
      const newTotal = (profile?.total_missions_completed || 0) + 1;
      await supabase
        .from('profiles')
        .update({ total_missions_completed: newTotal, updated_at: new Date().toISOString() })
        .eq('id', user.id);

      // Update arc progress missions_in_arc
      const currentArc = profile?.current_arc || 'comeback';
      const { data: arcData } = await supabase
        .from('arc_progress')
        .select('id, missions_in_arc')
        .eq('user_id', user.id)
        .eq('arc_type', currentArc)
        .maybeSingle();

      if (arcData) {
        await supabase
          .from('arc_progress')
          .update({
            missions_in_arc: arcData.missions_in_arc + 1,
            progress: Math.min(100, (arcData.missions_in_arc + 1) * 5),
            updated_at: new Date().toISOString(),
          })
          .eq('id', arcData.id);
      }

      // Refresh profile and show success
      await refreshProfile();
      setMissionSuccess(true);
      setPendingMission(null);

      // Also refresh latest episode to show updated status
      const { data: episodes } = await supabase
        .from('episodes')
        .select('*')
        .eq('user_id', user.id)
        .order('episode_number', { ascending: false })
        .limit(1);

      if (episodes && episodes.length > 0) {
        setLatestEpisode(episodes[0]);
      }

      setTimeout(() => setMissionSuccess(false), 3000);
    } catch {
      // Silently fail but reset loading state
    } finally {
      setMissionLoading(null);
    }
  };

  const handleMissionSkip = async () => {
    if (!pendingMission || !user) return;
    setMissionLoading('skip');

    try {
      await supabase
        .from('missions')
        .update({ status: 'skipped' })
        .eq('id', pendingMission.id);

      setPendingMission(null);
    } catch {
      // Silently fail but reset loading state
    } finally {
      setMissionLoading(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600/10 via-blue-600/5 to-transparent border border-violet-500/10 p-6 sm:p-8">
        <div className="absolute top-0 right-0 w-64 h-64 bg-violet-500/5 rounded-full blur-[80px] pointer-events-none" />

        <div className="relative z-10">
          <p className="text-violet-300/80 text-sm font-medium mb-1">
            Episode {nextEpisode}
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Hey, {displayName}.
          </h1>
          <p className="text-slate-400 text-sm sm:text-base max-w-md">
            Every day is a new chapter in your story. What's weighing on your mind today?
          </p>

          {/* Streak */}
          <div className="mt-5 flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/[0.04] border border-white/[0.06] rounded-xl px-4 py-2">
              <Flame className={`w-4 h-4 ${streak > 0 ? 'text-orange-400' : 'text-slate-500'}`} />
              <span className="text-sm font-semibold text-white">{streak}</span>
              <span className="text-xs text-slate-400">day streak</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mission completion success */}
      {missionSuccess && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <p className="text-sm font-medium text-emerald-300">Mission completed!</p>
            <p className="text-xs text-emerald-400/70">Your progress has been updated.</p>
          </div>
        </div>
      )}

      {/* Quick share button */}
      <Link
        to="/share"
        className="flex items-center gap-4 bg-gradient-to-r from-violet-600/20 to-blue-600/20 border border-violet-500/20 rounded-2xl p-5 hover:from-violet-600/30 hover:to-blue-600/30 transition-all group"
      >
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500/30 to-blue-500/30 flex items-center justify-center shrink-0">
          <PenLine className="w-5 h-5 text-violet-300" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-white group-hover:text-violet-200 transition">Share Your Thoughts</h3>
          <p className="text-sm text-slate-400">Type what's on your mind and get your next mission.</p>
        </div>
        <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-violet-400 transition shrink-0" />
      </Link>

      {/* Continue Journey / Pending Mission */}
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-5 h-5 text-violet-400 animate-spin" />
        </div>
      ) : (
        <>
          {pendingMission && (
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-semibold text-white">Your Current Mission</h3>
              </div>
              <p className="text-slate-300 text-sm mb-4">{pendingMission.content}</p>
              <div className="flex gap-2">
                <button
                  onClick={handleMissionComplete}
                  disabled={missionLoading !== null}
                  className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 disabled:opacity-50 text-white text-sm font-medium rounded-xl px-4 py-2 transition-all flex items-center gap-2"
                >
                  {missionLoading === 'complete' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : null}
                  Mark Complete
                </button>
                <button
                  onClick={handleMissionSkip}
                  disabled={missionLoading !== null}
                  className="bg-white/[0.04] border border-white/[0.08] text-slate-400 text-sm font-medium rounded-xl px-4 py-2 hover:text-white disabled:opacity-50 transition flex items-center gap-2"
                >
                  {missionLoading === 'skip' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : null}
                  Skip
                </button>
              </div>
            </div>
          )}

          {latestEpisode && (
            <Link
              to={`/episode/${latestEpisode.id}`}
              className="block bg-white/[0.02] border border-white/[0.06] rounded-2xl p-5 hover:bg-white/[0.04] hover:border-violet-500/20 transition-all group"
            >
              <p className="text-xs text-slate-500 mb-1">Last Episode</p>
              <h3 className="font-semibold text-white mb-1 group-hover:text-violet-200 transition">{latestEpisode.title}</h3>
              <p className="text-xs text-slate-400">
                {latestEpisode.mission_completed ? 'Mission completed' : 'Mission pending'} &middot; {latestEpisode.arc} arc
              </p>
              <div className="mt-2 flex items-center gap-1 text-xs text-slate-600 group-hover:text-violet-400 transition">
                <Eye className="w-3 h-3" />
                View details
              </div>
            </Link>
          )}
        </>
      )}
    </div>
  );
}
