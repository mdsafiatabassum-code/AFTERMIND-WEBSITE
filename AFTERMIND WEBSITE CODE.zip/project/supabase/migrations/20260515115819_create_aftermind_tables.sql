/*
  # AfterMind - New Tables for Emotional Clarity App

  1. New Tables
    - `thoughts` - user emotional inputs
    - `ai_responses` - AI-generated reality check, story interpretation, next mission
    - `episodes` - daily episode tracking with titles
    - `missions` - actionable missions from AI responses
    - `arc_progress` - emotional arc progression tracking

  2. Security
    - RLS enabled on all tables
    - Users can only access their own data
*/

CREATE TABLE IF NOT EXISTS thoughts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  category text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE thoughts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own thoughts"
  ON thoughts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own thoughts"
  ON thoughts FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own thoughts"
  ON thoughts FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS ai_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  thought_id uuid NOT NULL REFERENCES thoughts(id) ON DELETE CASCADE,
  reality_check text NOT NULL,
  story_interpretation text NOT NULL,
  next_mission text NOT NULL,
  episode_title text NOT NULL,
  arc_suggestion text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE ai_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own AI responses"
  ON ai_responses FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own AI responses"
  ON ai_responses FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  episode_number integer NOT NULL,
  thought_id uuid NOT NULL REFERENCES thoughts(id) ON DELETE CASCADE,
  response_id uuid NOT NULL REFERENCES ai_responses(id) ON DELETE CASCADE,
  arc text NOT NULL DEFAULT 'comeback',
  mission_completed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE episodes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own episodes"
  ON episodes FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own episodes"
  ON episodes FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own episodes"
  ON episodes FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS missions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  source_response_id uuid NOT NULL REFERENCES ai_responses(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE missions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own missions"
  ON missions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own missions"
  ON missions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own missions"
  ON missions FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own missions"
  ON missions FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS arc_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  arc_type text NOT NULL,
  progress integer NOT NULL DEFAULT 0,
  episodes_in_arc integer NOT NULL DEFAULT 0,
  missions_in_arc integer NOT NULL DEFAULT 0,
  started_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, arc_type)
);

ALTER TABLE arc_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own arc progress"
  ON arc_progress FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own arc progress"
  ON arc_progress FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own arc progress"
  ON arc_progress FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Indexes
CREATE INDEX IF NOT EXISTS idx_thoughts_user_id ON thoughts(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_responses_thought_id ON ai_responses(thought_id);
CREATE INDEX IF NOT EXISTS idx_episodes_user_id ON episodes(user_id);
CREATE INDEX IF NOT EXISTS idx_missions_user_id ON missions(user_id);
CREATE INDEX IF NOT EXISTS idx_arc_progress_user_arc ON arc_progress(user_id, arc_type);

-- Update the trigger to also initialize arc progress
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));

  INSERT INTO public.arc_progress (user_id, arc_type) VALUES
    (NEW.id, 'comeback'),
    (NEW.id, 'healing'),
    (NEW.id, 'burnout'),
    (NEW.id, 'discipline'),
    (NEW.id, 'confidence');

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
