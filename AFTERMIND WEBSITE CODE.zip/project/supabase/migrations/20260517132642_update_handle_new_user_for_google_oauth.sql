/*
  # Update handle_new_user trigger for Google OAuth support

  1. Changes
    - Updated `handle_new_user()` function to capture Google OAuth data:
      - `avatar_url` from `raw_user_meta_data->>'avatar_url'` (Google provides this)
      - `display_name` from `raw_user_meta_data->>'full_name'` (Google provides this)
        with fallback to `raw_user_meta_data->>'display_name'` (custom signup)
        with fallback to email username prefix
    - Fixed overly permissive SELECT policy on `profiles` table
      - Changed from `USING (true)` to `USING (auth.uid() = id)` so users can only read their own profile

  2. Security
    - Profiles SELECT policy now restricts to own data only (was `true`, now `auth.uid() = id`)
    - All other policies remain unchanged

  3. Important Notes
    - Google OAuth stores user metadata in `raw_user_meta_data` with keys:
      - `full_name`: The user's Google display name
      - `avatar_url`: The user's Google profile picture URL
      - `email`: The user's Google email
    - Email/password signup stores `display_name` in `raw_user_meta_data->>'display_name'`
    - The trigger handles both flows with COALESCE fallbacks
*/

-- Drop the old trigger first
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Update the function to capture Google OAuth data
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      NEW.raw_user_meta_data->>'display_name',
      split_part(NEW.email, '@', 1)
    ),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', NULL)
  );

  INSERT INTO public.arc_progress (user_id, arc_type) VALUES
    (NEW.id, 'comeback'),
    (NEW.id, 'healing'),
    (NEW.id, 'burnout'),
    (NEW.id, 'discipline'),
    (NEW.id, 'confidence');

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Fix the overly permissive SELECT policy on profiles
DROP POLICY IF EXISTS "Anyone can view profiles" ON profiles;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);
