import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { thought, category, episodeNumber, currentArc } = body;

    if (!thought || !thought.trim()) {
      return new Response(
        JSON.stringify({ error: "Thought content is required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("OPENAI_API_KEY");

    if (apiKey) {
      return await handleWithAI(apiKey, thought, category, episodeNumber, currentArc, corsHeaders);
    }

    const response = generateFallbackResponse(thought, category, episodeNumber, currentArc);
    return new Response(
      JSON.stringify(response),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function handleWithAI(
  apiKey: string,
  thought: string,
  category: string,
  episodeNumber: number,
  currentArc: string,
  corsHeaders: Record<string, string>
): Promise<Response> {
  const systemPrompt = `You are AfterMind — a quiet voice that understands what someone is going through before they fully understand it themselves.

You do NOT coach. You do NOT motivate. You do NOT give advice. You do NOT use words like "hero," "protagonist," "main character," "journey," "transformation," or "growth."

Instead, you do what good storytelling does: you notice the thing someone is feeling but hasn't said out loud yet. You name it quietly. You make them feel seen.

Your voice is:
- Like a late-night thought you didn't expect to have
- Like the narration in a coming-of-age film — observant, not preachy
- Like something you'd write in a journal at 2am and then close the book
- Short. 1-3 sentences max per section. Every word earns its place.
- Emotionally precise, not emotionally loud
- Human and imperfect — the way real people actually think and feel

TONE RULES — NEVER DO THESE:
- No motivational quotes or inspirational language
- No "you've got this" or "believe in yourself" energy
- No corporate wellness tone ("self-care," "wellness journey," "growth mindset")
- No fake-deep philosophical statements
- No "main character" or "hero" or "protagonist" framing
- No exclamation marks
- No commands disguised as encouragement
- No listing what they "should" do
- No toxic positivity
- No repeating their words back with "and that's okay" attached

TONE RULES — ALWAYS DO THESE:
- Name the feeling underneath the feeling (they say "tired," you see "running on empty for so long that empty started feeling normal")
- Use concrete, specific imagery over abstract concepts
- Let silence do work — don't over-explain
- Write like you're observing a real moment, not giving a speech
- Be concise enough that someone would want to share it
- Make them feel understood, not advised

You respond with JSON containing:
- "reality_check": Name what's actually happening underneath what they said. Not advice. Just the quiet truth they might not have admitted yet. Like: "Some nights weren't sad. Just emotionally loud."
- "story_interpretation": Tell a short story about where they are right now. 5-6 lines. Write like a parent or mentor telling a story at the kitchen table — natural, unhurried, full of small details, with a quiet truth buried inside. Not a lecture. Not a metaphor. A real story about a real feeling. Like someone remembering something out loud. Use "you" naturally. Let the story breathe. End on something small and true, not a lesson.
- "next_mission": One small, specific thing they can do today. Not a life change. Not a habit. Just one quiet action. 10-30 minutes. Write it like a gentle suggestion, not a command. Like: "Go somewhere quiet for 15 minutes. Don't take your phone. Just sit."
- "episode_title": A cinematic, understated episode title. No "Episode X:" prefix — just the title itself. Like: "The Night Standing Still Felt Like Falling" or "When Quiet Started Feeling Like Giving Up"
- "arc_suggestion": Which emotional arc this fits: comeback, healing, burnout, discipline, or confidence

The user's current arc is: ${currentArc || 'comeback'}
The episode number is: ${episodeNumber || 1}
The category is: ${category || 'general'}`;

  const userPrompt = `Here's what's on my mind: "${thought}"`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        max_tokens: 500,
        temperature: 0.9,
        response_format: { type: "json_object" },
      }),
    });

    const data = await response.json();
    let parsed;
    try {
      parsed = JSON.parse(data.choices?.[0]?.message?.content || "{}");
    } catch {
      parsed = generateFallbackResponse(thought, category, episodeNumber, currentArc);
    }

    // Ensure episode title includes the number
    if (parsed.episode_title && !parsed.episode_title.includes(String(episodeNumber))) {
      parsed.episode_title = `Episode ${episodeNumber}: ${parsed.episode_title}`;
    }

    return new Response(
      JSON.stringify(parsed),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch {
    const fallback = generateFallbackResponse(thought, category, episodeNumber, currentArc);
    return new Response(
      JSON.stringify(fallback),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}

function generateFallbackResponse(
  thought: string,
  category: string,
  episodeNumber: number,
  currentArc: string
): Record<string, string> {
  const ep = episodeNumber || 1;
  const arc = currentArc || 'comeback';
  const cat = category || 'overthinking';

  const realityChecks: Record<string, string[]> = {
    overthinking: [
      "The thoughts aren't the problem. It's the belief that thinking harder will solve something that thinking caused.",
      "You keep replaying conversations that haven't happened yet. The future you're worried about is being written by a mind that's already exhausted.",
      "Overthinking isn't insight. It's the same room with the lights flicked on and off, over and over, expecting something different each time.",
    ],
    discipline: [
      "It's not that you don't care enough. It's that caring quietly for so long started to look like not caring at all.",
      "The gap between knowing and doing isn't laziness. It's the weight of having to start over — again — when you're already tired from the last time.",
      "Discipline sounds like a strong word for something that's really just showing up when no one's watching and nothing feels different.",
    ],
    burnout: [
      "You've been running on empty for so long that empty started feeling like a full tank. It's not.",
      "It wasn't one big thing that broke you. It was a thousand small ones you kept carrying because none of them felt heavy enough to put down.",
      "The problem wasn't that you were weak. You were just tired for too long.",
    ],
    confidence: [
      "You keep waiting for the moment you feel ready. That moment doesn't exist. Ready is something you become by walking into the thing that scares you.",
      "Confidence isn't the absence of doubt. It's the decision to move with it instead of around it.",
      "You've been shrinking yourself to fit rooms that were never your size.",
    ],
    healing: [
      "Healing doesn't announce itself. It's the morning you wake up and the first thought isn't the one that's been hurting you.",
      "You're not going backwards. Some days just weigh more than others, and that doesn't erase the lighter ones.",
      "The fact that you're still here isn't weakness. It's the quietest kind of strength there is.",
    ],
    motivation: [
      "Motivation was never going to show up. It's not waiting around the corner. The only thing that moves you forward is deciding to move without it.",
      "You're not stuck. You're standing at the edge of something, and the edge always feels like standing still.",
      "The thing you keep putting off isn't as big as the space it's taking up in your head.",
    ],
  };

  const storyInterpretations: Record<string, string[]> = {
    overthinking: [
      `You know that feeling when you're lying in bed and the room is completely quiet, but your mind isn't? It just keeps going — replaying things that happened, running through things that might happen, building scenarios out of nothing. And the worst part is, you know it's happening. You can see yourself doing it. But watching yourself overthink doesn't make it stop. It just adds another layer — now you're overthinking about overthinking. That's where you are right now. Stuck in a room you built yourself, and the door was open the whole time.`,
      `There's this thing that happens when you care too much about getting something right. You start double-checking everything. Not because you're unsure, but because being wrong once was so heavy that you decided never to let it happen again. So you rehearse conversations that haven't happened yet. You prepare for reactions no one's going to have. You build walls around problems that don't exist yet. And after a while, all that preparing starts to look a lot like not living. That's the thing no one tells you about being careful — sometimes it becomes its own kind of trap.`,
      `When you were younger, someone probably told you to think before you act. And that was good advice, most of the time. But nobody told you what happens when thinking becomes the only thing you do. When every decision needs to be analyzed from every angle before you can even take a step. It's like standing at a crossroads and being so afraid of choosing the wrong road that you never leave the intersection. The cars keep passing. The sun starts setting. And you're still there, thinking about which way to go, while the day quietly disappears.`,
    ],
    discipline: [
      `Here's the thing about discipline that nobody talks about — it's not about willpower. Willpower runs out. It's like a phone battery. You charge it overnight, and by noon, it's already half gone. The people who seem disciplined aren't fighting themselves every day. They just stopped negotiating. They made a decision once, and they stopped reopening it every morning like it's a case that needs more evidence. You keep having the same conversation with yourself — should I, shouldn't I — and that conversation takes more energy than just doing the thing. That's where you are. Not lazy. Just tired from arguing with yourself.`,
      `You know what's harder than starting over? Starting over when nobody's watching. The first time you try something, there's energy in it. People notice. You notice. But the second time, the fifth time, the twentieth time you try to build the same habit — that's when it gets quiet. No one's cheering. You're just there, alone, doing the same small thing again. And it doesn't feel like progress. It feels like a loop. But here's what I've seen — the loop is the work. The repetition isn't failure. It's the thing that makes the change real. It just doesn't look like much while you're in it.`,
      `There was a time when you did things without thinking about them. Not because you were careless, but because the distance between wanting to do something and actually doing it was short. Now that distance has grown. There's a whole conversation that happens before every action — a debate, a negotiation, a weighing of options. And by the time you've decided, the moment has passed. The thing about discipline isn't that it makes you do things. It's that it shortens the distance again. It removes the debate. You just go.`,
    ],
    burnout: [
      `You know that feeling when you've been carrying something for so long that you forget you're even holding it? Like a bag you picked up years ago, and your arms just got used to the weight. You don't notice it anymore. But then one day, someone asks you to hold one more thing — just one small thing — and you can't. Not because it's heavy. Because your arms have been full this whole time. That's what burnout feels like. It's not a sudden collapse. It's the slow realization that you've been at capacity for longer than you remember, and there's nothing left to give.`,
      `When you're burning out, the world doesn't stop. That's the hardest part. The emails still come. The responsibilities don't shrink. People still need things from you. And you keep showing up because that's what you've always done. But somewhere inside, the engine is running on fumes. You're not lazy. You're not weak. You're just a person who kept going when they should have stopped, and now stopping feels impossible because stopping means admitting that you can't keep going. That's the trap. The only way out is to put something down — not everything. Just one thing. And see how it feels.`,
      `There's a kind of tired that sleep doesn't fix. You know the one. You sleep eight hours and wake up tired. You take a day off and it doesn't help. That's because the tired isn't in your body — it's in the way you've been living. Running on autopilot. Saying yes when you mean no. Showing up because not showing up feels worse. After a while, everything costs something, and you've been paying with pieces of yourself for so long that you forgot energy was supposed to be free. You're not broken. You're just depleted. And depleted takes time. Not a weekend. Real time.`,
    ],
    confidence: [
      `You know that thing where you walk into a room and you can feel yourself shrinking? Not physically — but something inside you gets smaller. You start measuring your words. You laugh at things that aren't funny just to belong. You agree when you don't agree. And after a while, you don't even notice you're doing it anymore. It just becomes how you move through the world — careful, quiet, making yourself easy for other people to be around. But the cost of being easy for everyone else is that you become hard to find. Even for yourself.`,
      `When you were a kid, you probably didn't question whether you belonged somewhere. You just showed up. You ran, you talked, you said whatever came to mind. Confidence wasn't something you had — it was just the absence of the question. Then somewhere along the way, someone made you doubt. Or maybe it wasn't someone. Maybe it was just time, and failure, and the slow accumulation of moments where you didn't measure up to the picture in your head. And now the question is always there: am I enough? The answer hasn't changed. You just stopped hearing it.`,
      `There's a version of you that doesn't second-guess every word before saying it. That doesn't rehearse conversations in the shower. That doesn't walk into a room already apologizing for being there. That version isn't some future, better you. It's just you without the weight of every time someone made you feel small. The thing about confidence is that it's not something you build. It's something you uncover. It's been there the whole time. It's just buried under a lot of other people's opinions that you accidentally started carrying.`,
    ],
    healing: [
      `Healing is strange because it doesn't look like anything. There's no moment where you can point and say — there, that's when it happened. It's more like a bruise fading. You don't watch it change. You just wake up one morning and notice it doesn't hurt the same way when you press on it. And some days it still hurts. That doesn't mean you're going backwards. It just means healing isn't a line — it's weather. Some days are clear. Some days it rains. But the seasons do change, even when it doesn't feel like it from inside the storm.`,
      `Nobody tells you that healing is boring. We talk about it like it's this beautiful, transformative thing. But most of the time, it's just showing up. Doing the small things. Eating. Sleeping. Going outside. Not because you want to, but because you know that if you stop, everything falls apart again. And that's not glamorous. That's not a story you tell at dinner. But it's the real work. The quiet, unremarkable, day-after-day work of choosing to stay. That's what healing actually looks like. Not a breakthrough. Just a series of small decisions to keep going.`,
      `You know how sometimes you're fine for a while, and then something small happens — a song, a smell, a phrase someone says — and suddenly you're back there? Back in the thing you thought you'd moved past. That's the part about healing that people don't prepare you for. The returning. It doesn't mean you failed. It means the wound was real, and real things leave marks. A scar isn't a sign that you didn't heal. It's a sign that you did. The skin just grew back different. Stronger where it had to be.`,
    ],
    motivation: [
      `Here's what I've noticed about motivation — it's not something you find. It's something that was there, and then got buried under all the times you started and stopped. Under all the plans that didn't work out. Under the mornings you woke up meaning to change things and the nights you went to bed having changed nothing. After a while, the distance between wanting and doing gets so wide that you stop believing the wanting is real. But it is. It's just quiet now. Buried under disappointment. The way to find it again isn't to wait for it to get loud. It's to do one small thing before it has a chance to talk you out of it.`,
      `You know that feeling when you're sitting somewhere and you know you should be doing something else, but you can't make yourself get up? It's not that you don't care. It's that caring has become this heavy, abstract thing — like a weight with no shape. You can't pick it up because you can't find the edges. That's what happens when the thing you want is too big to hold. You have to make it smaller. Not the dream — just the next step. Shrink it down until it's something you can do in the next ten minutes. Then do that. The rest of it can wait. It's not going anywhere.`,
      `There's a kind of stuck that isn't about not knowing what to do. You know what to do. You've known for a while. The problem is that knowing and doing live in different rooms, and the hallway between them has gotten longer. Every day, you think about walking down that hallway. And every day, something easier wins. Not because you're lazy. Because the thing that's easier doesn't come with the risk of failing again. That's the real weight — not the task itself, but the memory of all the times you tried and it didn't stick. But here's the thing: this time isn't last time. It just feels the same.`,
    ],
  };

  const missions: Record<string, string[]> = {
    overthinking: [
      "Set a 10-minute timer. Write down every worry. When it ends, close the list. Pick one. Do one small thing about it. Leave the rest for another day.",
      "Pick the thought that's been looping the longest. Say it out loud. Ask: is this happening right now, or is this a story about something that might happen?",
      "Go somewhere without your phone for 10 minutes. Let the thoughts come. Don't fight them. Just notice which ones keep coming back.",
    ],
    discipline: [
      "Pick one thing you've been avoiding. Set a timer for 10 minutes. Work on it. When the timer rings, you can stop. But finish the 10 minutes.",
      "Write down three things for today. Not five. Not ten. Three. Do the easiest one first. Let the momentum carry you.",
      "Do something hard for exactly 5 minutes. If you want to stop after, stop. But give it 5 real minutes first.",
    ],
    burnout: [
      "Cancel one thing today that you don't actually need to do. Use that time to do nothing. Not 'productive nothing.' Just nothing.",
      "Say no to one thing today. Not because you can't — because you shouldn't have to. Your energy is finite. Act like it.",
      "Take 20 minutes with zero screens. Lie down. Close your eyes. This isn't laziness. This is the thing you've been avoiding that would actually help.",
    ],
    confidence: [
      "Do one thing today that makes you slightly uncomfortable. Not terrifying. Just a small step outside the space you've been shrinking into.",
      "Write down three things you've done that you're proud of. Small things count. Read them back. Let yourself feel it for a moment.",
      "Stand somewhere quiet for 60 seconds. Breathe. Remind yourself: you're allowed to take up space here.",
    ],
    healing: [
      "Write a few words to yourself from six months from now. Not advice. Just what you'd want someone in your position to hear.",
      "Do one gentle thing for your body today. Stretch. Take a long shower. Go to sleep early. Your body carries what your mind can't process yet.",
      "Name one small thing that made today slightly less heavy. Not the big stuff. The quiet, almost-invisible thing.",
    ],
    motivation: [
      "Do the smallest possible version of the thing you're avoiding. One pushup. One sentence. One email. Start so small it almost doesn't count.",
      "Set a 2-minute timer. Work on the thing. When it rings, you can stop. But you probably won't want to.",
      "Tell one person what you're working toward. Not for accountability. Just to hear yourself say it out loud.",
    ],
  };

  const episodeTitles = [
    "The Night Standing Still Felt Like Falling",
    "When Quiet Started Feeling Like Giving Up",
    "The Space Between Tired and Done",
    "The Morning That Didn't Feel Like a Beginning",
    "When the Noise Became the Only Thing Left",
    "The Day Pretending Got Too Heavy",
    "Somewhere Between Who I Was and Who I'm Not Yet",
    "The Chapter I Wanted to Skip",
    "Standing Still in a Room Full of Moving People",
    "The Weight I Forgot I Was Carrying",
    "When the Mirror Showed Someone Tired",
    "The First Step After the Longest Pause",
    "Rewriting the Same Day",
    "The Night I Chose Differently",
    "Breaking the Loop I Didn't Know I Was In",
    "The Morning the Fog Lifted a Little",
    "When Rest Became the Hardest Thing",
    "The Bridge I Was Afraid to Cross",
    "The Decision I Kept Putting Off",
    "The Day I Stopped Running From Myself",
  ];

  const catChecks = realityChecks[cat] || realityChecks.overthinking;
  const catStories = storyInterpretations[cat] || storyInterpretations.overthinking;
  const catMissions = missions[cat] || missions.overthinking;

  const randomPick = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];
  const titleBase = episodeTitles[(ep - 1) % episodeTitles.length];

  return {
    reality_check: randomPick(catChecks),
    story_interpretation: randomPick(catStories),
    next_mission: randomPick(catMissions),
    episode_title: `Episode ${ep}: ${titleBase}`,
    arc_suggestion: arc,
  };
}
